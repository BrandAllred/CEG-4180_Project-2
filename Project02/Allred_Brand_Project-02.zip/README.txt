Brand Allred
Proffessor Eric Buck
CEG 4180
8/4/2019

This project represents my attempt at the message design pattern.

Sending, recieving, and handling messages are all handled in the SpaceShip Abstract class.

The Board handles where the ships are, and what ships there are. And the ships knowing who eachother are.

I used DTO objects to serialize and send messages between threads. This allows for a simple, agreed upon way for each SpaceShip concrete class to interact with eachother.
The DTOs also allow for new types of ships to be made, and even ships that are not even a part of the same program. Or even written in the same language. This is because the DTOs are serialized into JSON.

And through correcting the implementation to have it so that the board is the only class to deal with interactions between ships, there is the possibility to have it so that the board class is on a different server. Thus making it so all calls to the board are API call through a network.
Thus also allowing for each thread to be processed on a different computer.

*******************IMPORTANT**************************
Package info:
	Newtonsoft.json version 12.0.2
	C# version 4.6.1

Thanks for the class.

